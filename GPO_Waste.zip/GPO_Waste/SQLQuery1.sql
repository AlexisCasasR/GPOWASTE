CREATE DATABASE GPO_Waste;
go
CREATE TABLE USUARIO
(
	U_Id Integer Primary Key,
	U_Nombre Varchar(50) NOT NULL,
	U_Nit Varchar(13),
	U_User Varchar(10) NOT NULL,
	U_Pass Varchar(10) NOT NULL,
	U_Email Varchar(100) NOT NULL,
	U_Direccion Varchar(100) NOT NULL,
	U_Tipo char NOT NULL
)

ALTER TABLE USUARIO
ALTER COLUMN U_User Varchar(100) NOT NULL



select U_Tipo from USUARIO where U_User = 'xdaferx@gmail.com' and U_Pass = 'fmartz29';

