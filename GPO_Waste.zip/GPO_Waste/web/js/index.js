$(document).ready(function(){
    $("#myModal").click(function(){
        $("#myModal").modal();
    });
});