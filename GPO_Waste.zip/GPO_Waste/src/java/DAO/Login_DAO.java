/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DAO;

import Conexion.Conectate;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 *
 * @author FMARTZ
 */
public class Login_DAO {
    
    public int validarUsuario(String user, String pass, String tipo)
    {
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        int mp=0;
        try{
            con = Conectate.getConnection();
            String sql = "SELECT CASE WHEN EXISTS ( select * from USUARIO where U_User = '"+user+"' and U_Pass = '"+pass+"' and U_Tipo = '"+tipo+"' ) THEN CAST(1 AS BIT) ELSE CAST(0 AS BIT) END AS VALIDAR";
            pstm = con.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while( rs.next() )
            {
                mp = rs.getInt("VALIDAR");
            }
            return mp;
        }
        catch( SQLException ex ){
            throw new RuntimeException(ex);
        }
        finally{
            try{
                if( rs!=null ) rs.close();
                if( pstm!=null ) pstm.close();
            }
            catch(SQLException ex){
                throw new RuntimeException(ex);
            }
        }
    }
    
    public String retornarName(String user, String pass)
    {
        Connection con = null;
        PreparedStatement pstm = null;
        ResultSet rs = null;
        String mp = "";
        try{
            con = Conectate.getConnection();
            String sql = "select U_Nombre from USUARIO where U_User = '"+user+"' and U_Pass = '"+pass+"';";
            pstm = con.prepareStatement(sql);
            rs = pstm.executeQuery();
            
            while( rs.next() )
            {
                mp = rs.getString(1);
            }
            return mp;
        }
        catch( SQLException ex ){
            throw new RuntimeException(ex);
        }
        finally{
            try{
                if( rs!=null ) rs.close();
                if( pstm!=null ) pstm.close();
            }
            catch(SQLException ex){
                throw new RuntimeException(ex);
            }
        }
    }
    
    
}
