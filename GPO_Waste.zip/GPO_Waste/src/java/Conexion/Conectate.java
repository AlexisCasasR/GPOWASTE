package Conexion;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

/**
 *
 * @author FRANKPE
 */
public class Conectate 
{
    private static Connection con = null;
    
    public static Connection getConnection()
    {
        try{
            if( con == null ){ 
                Runtime.getRuntime().addShutdownHook(new MiShDwnHook());
                String bd="GPO_Waste";
                String driver="com.microsoft.sqlserver.jdbc.SQLServerDriver";
                String url="jdbc:sqlserver://localhost;databasename=" + bd;
                String usr="conexion";
                String pwd="123456";
                Class.forName(driver);
                con = DriverManager.getConnection(url,usr,pwd);
            }
            return con;
        }
        catch(ClassNotFoundException | SQLException ex){
            throw new RuntimeException("Error al crear la conexion",ex);
        }
    }
    
    static class MiShDwnHook extends Thread
    { // justo antes de finalizar el programa la JVM invocara
    // a este metodo donde podemos cerrar la conexion
        @Override
        public void run()
        {
            try{
                Connection con = Conectate.getConnection();
                con.close(); 
            } 
            catch( SQLException ex ){
                throw new RuntimeException(ex);
            }
        }
    }
}
