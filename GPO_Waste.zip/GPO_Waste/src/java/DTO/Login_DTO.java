/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DTO;

/**
 *
 * @author FMARTZ
 */
public class Login_DTO {
    private int U_Id;
    private String U_Nombre;
    private String U_Nit;
    private String U_User;
    private String U_Pass;
    private String U_Email;
    private String U_Direccion;
    private String U_Tipo;

    public int getU_Id() {
        return U_Id;
    }

    public void setU_Id(int U_Id) {
        this.U_Id = U_Id;
    }

    public String getU_Nombre() {
        return U_Nombre;
    }

    public void setU_Nombre(String U_Nombre) {
        this.U_Nombre = U_Nombre;
    }

    public String getU_Nit() {
        return U_Nit;
    }

    public void setU_Nit(String U_Nit) {
        this.U_Nit = U_Nit;
    }

    public String getU_User() {
        return U_User;
    }

    public void setU_User(String U_User) {
        this.U_User = U_User;
    }

    public String getU_Pass() {
        return U_Pass;
    }

    public void setU_Pass(String U_Pass) {
        this.U_Pass = U_Pass;
    }

    public String getU_Email() {
        return U_Email;
    }

    public void setU_Email(String U_Email) {
        this.U_Email = U_Email;
    }

    public String getU_Direccion() {
        return U_Direccion;
    }

    public void setU_Direccion(String U_Direccion) {
        this.U_Direccion = U_Direccion;
    }

    public String getU_Tipo() {
        return U_Tipo;
    }

    public void setU_Tipo(String U_Tipo) {
        this.U_Tipo = U_Tipo;
    }
    
    
}
